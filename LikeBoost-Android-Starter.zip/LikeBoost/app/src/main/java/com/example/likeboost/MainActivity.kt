package com.example.likeboost

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("likeboost_stats", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel()
        requestNotificationPermission()
        scheduleReminder()

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 48, 40, 32)
        }

        val heading = TextView(this).apply {
            text = "LikeBoost"
            textSize = 30f
        }
        val intro = TextView(this).apply {
            text = "Background profile-growth companion"
            textSize = 16f
        }
        val gumCount = TextView(this).apply { textSize = 20f }
        val mozCount = TextView(this).apply { textSize = 20f }
        val status = TextView(this).apply {
            text = "Background reminder: scheduled every 6 hours"
            textSize = 14f
        }

        fun refresh() {
            gumCount.text = "ChatGum likes received: ${prefs.getInt("gum", 0)}"
            mozCount.text = "ChatMoz likes received: ${prefs.getInt("moz", 0)}"
        }

        fun counterButton(label: String, key: String): Button =
            Button(this).apply {
                text = label
                setOnClickListener {
                    prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
                    refresh()
                }
            }

        layout.addView(heading)
        layout.addView(intro)
        layout.addView(gumCount)
        layout.addView(counterButton("Record a new ChatGum like", "gum"))
        layout.addView(mozCount)
        layout.addView(counterButton("Record a new ChatMoz like", "moz"))
        layout.addView(status)
        layout.addView(TextView(this).apply {
            text = "Note: counts are entered manually. This app does not generate likes or control either social app."
            textSize = 13f
        })
        refresh()
        setContentView(layout)
    }

    private fun scheduleReminder() {
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "likeboost_profile_reminder",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ReminderWorker.CHANNEL_ID,
                "Profile reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Reminders to review your profile activity" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100
            )
        }
    }
}
