# LikeBoost Android starter

A small Android Studio starter project for background profile-growth reminders and manually recorded likes for ChatGum and ChatMoz.

## Included
- Android Kotlin app targeting Android 16 (API 36).
- WorkManager periodic reminder, scheduled every 6 hours.
- Android notification permission handling.
- Local manual counters for ChatGum and ChatMoz.

## Important limitations
This starter does **not** create, buy, exchange, or automatically send likes. It does not log into, scrape, or control ChatGum or ChatMoz. It cannot read either app's private like count. Counts are entered manually by the user. Automated likes would require an official, authorized API from the relevant app; do not share passwords or session tokens with third-party automation.

WorkManager is battery-aware and does not guarantee an exact execution time. Android may defer background work based on battery and system conditions.

## Build
1. Install Android Studio with Android SDK Platform 36.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect your Android 16 phone with USB debugging enabled, or use an emulator.
5. Press **Run**.

The first launch requests notification permission. If denied, the app still works, but background reminders will not be shown.

## Package
`com.example.likeboost`

Change the application ID and signing configuration before publishing.
